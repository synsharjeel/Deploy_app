// var url = "https://sketchfab.com/models/935c66c0f64647b39888a84228cc1faf/embed?api_version=1.3.0&api_id=9418229855091305";
// var datadiv = document.getElementById('data');
// console.log(data);
function makeannotation(api) {
    var datadiv = document.getElementById('api-frame');
    console.log(datadiv.isContentEditable);
    // $('#myModal').modal('show');
    
    $('#showForm').css('display','inline-block');
    var btn = document.querySelector("#apply_item");
    btn.addEventListener('click', function () {
        var form = document.querySelector("#items_form");
        event.preventDefault();
        if (form.annotation.value !== "") {
            // var img, text, color,bgcolor, width, height, div;
            var updateObj ={};
            // var div = document.createElement('div');
            if (form.title.value !== '') {
                
                updateObj.title = form.title.value;
                // div.appendChild(text)
            }
            var annotation = `<div class="one" >`;
            if (form.imgpath.value !== '') {
                annotation +=`<img  src="${form.imgpath.value}" alt="not found"
                />`
                // width="${(form.width.value) ? form.width.value - 30 : 100}"
                // height="${(form.height.value) ? form.height.value : 100}"
            }
            if(form.text.value !== ""){
                annotation +=`<div >${form.text.value}</div>`
            }
            annotation +=`</div>`;
            updateObj.content  = annotation
            api.updateAnnotation(form.annotation.value,updateObj,function(err,information){
                console.log(information);
                $('#myModal').modal('hide');
                api.gotoAnnotation(form.annotation.value);
            });
            // document.body.appendChild(annotation);
        } else {
            alert("Please select annotation first");
        }
    });

}