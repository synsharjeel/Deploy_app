'use strict';

var $ = require('jquery');
var _ = require('underscore');
var Backbone = require("backbone");
Backbone.$ = $;
var AppView = require('./views/App');

var appView = new AppView();
