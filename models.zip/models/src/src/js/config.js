var config = {
    URLID: '1e490d0f4d434ff68caa38f00792adda'
};

module.exports = config;
